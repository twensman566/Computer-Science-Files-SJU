/**
 * IntegerLiteral.java
 */

package expressions;

/**
 * Used for the numbers.
 * 
 * @author Zachary Vetter, Alexis Neas, Trevor Wensman
 * @version 9/20/2017
 */
public class IntegerLiteral extends Operand
{
  
  public Integer newInteger;
  
  /**
   * Parses a string into an integer.
   * 
   * pre: the string must be an integer.
   * @param string the string you want to change to an integer.
   * 
   * @throws IllegalArgumentException if pre condition is not met
   */
  public IntegerLiteral(String string)
  {
    this(Integer.parseInt(string));
    
  }
  
  /**
   * Creates a number.
   */
  public IntegerLiteral(int aNumber)
  {
    newInteger = aNumber;
  }
  
  /**
   * Taken from the super class.
   */
  public int getValue()
  {
    return newInteger;
  }
  
  /**
   * Taken from the interface.
   * 
   */
  public String toString()
  {
   return Integer.toString(this.getValue()); 
  }
}