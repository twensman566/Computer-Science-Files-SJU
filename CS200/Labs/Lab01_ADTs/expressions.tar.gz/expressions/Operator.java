/**
 * Operator.java
 */

package expressions;

/**
 * Used for the Operators of the expression
 * 
 * @author Zachary Vetter, Alexis Neas, Trevor Wensman
 * @version 9/20/2017
 */
public abstract class Operator implements Token {
  
  /**
   * Returns the precendence of the operators
   * 
   * @return returns 1 for lower precedence and 2 for higher
   */
  public abstract int getPrecedence();
  
  /**
   * Performs the appropriate operation on the values of the two operands
   * 
   * @param operand1 the first operand
   * @param operand2 the second operand
   * 
   * @return returns the new integer literal operand
   */
  public abstract Operand evaluate(Operand operand1, Operand operand2);
  
  /**
   * Taken from interface.
   */
  public Token.Type getType()
  {
    return Type.OPERATOR;
  }
}