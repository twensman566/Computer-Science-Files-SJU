/**
 * Operand.java
 */

package expressions;

/**
 * Used for the Operands of the expression
 * 
 * @author Zachary Vetter, Alexis Neas, Trevor Wensman
 * @version 9/20/2017
 */
public abstract class Operand implements Token{
 
  /**
   * Gets the value of each operand
   * 
   * @return the int value
   */
  public abstract int getValue();
  
    /**
   * Taken from interface.
   */
  public Token.Type getType()
  {
    return Type.OPERAND;
  }
}