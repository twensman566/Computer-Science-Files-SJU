/**
 * LeftParenthesis.java
 */

package expressions;

/**
 * Used for left parenthesis in the expression
 * 
 * @author Alexis Neas, Zachary Vetter, Trevor Wensman
 * @version 9/20/2017
 */
public class LeftParenthesis implements Token{
  
  /**
   * Taken from the interface.
   */
  public Token.Type getType()
  {
    return Type.LEFT_PARENTHESIS;
  }
  
  /**
   * Taken from the interface.
   */
  public String toString()
  {
    return "(";
  }
}