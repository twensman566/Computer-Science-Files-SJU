/**
 * Divide.java
 */

package expressions;
import java.util.*;

/**
 * .
 * 
 * @author Zachary Vetter, Alexis Neas, Trevor Wensman
 * @version 9/20/2017
 */
public class InfixToPostfixV2{
  
  
  /**
   * Takes and infixQueue and returns the equivalent postfixQueue.
   * 
   * @param infixQueue the infixQueue
   * @return postfixQueue 
   */
  public static BDKLinkedQueue<Token> convert(BDKLinkedQueue<Token> infixQueue)
  {
    
    if(infixQueue.isEmpty())
    {
      throw new IllegalArgumentException("Empty infix expression");
    }
    Token topTok = null;
    Queue<Token> postfixQueue = new ArrayDeque<Token>();
    Stack<Token> opStack = new Stack<Token>();
    
    while(!infixQueue.isEmpty())
    {
      topTok = infixQueue.remove();
      if(topTok instanceof Operand)
      {
        postfixQueue.add(topTok);
      }
      else if(topTok instanceof LeftParenthesis)
      {
        opStack.push(topTok);
      }
      else if(topTok instanceof RightParenthesis)
      {
        processRightParenthesis(opStack,postfixQueue);
      }
      else
      {
        processOperator(opStack,postfixQueue,(Operator)topTok);
      }
    }
    while(!opStack.isEmpty())
    {
      topTok = opStack.pop();
      if(topTok instanceof LeftParenthesis)
      {
        throw new IllegalArgumentException("Unmatched left parenthesis"); 
      }
      postfixQueue.add(topTok);
    }
    
    
    
    return postfixQueue;
  }
  
  /**
   * Takes and infixQueue and returns the equivalent postfixQueue.
   * 
   * @param infixQueue the infixQueue
   */
  private static void processRightParenthesis(Stack<Token> opStack, Queue<Token> postfixQueue)
  {
    while(!opStack.isEmpty() && !(opStack.peek() instanceof LeftParenthesis))
    {
      postfixQueue.add(opStack.pop());
    }
    if(opStack.isEmpty())
    {
      throw new IllegalArgumentException("Unmatched right parenthesis"); 
    } 
    opStack.pop();
  }
  /**
   * Takes and infixQueue and returns the equivalent postfixQueue.
   * 
   * @param opStack the stack of operators
   * @param postfixQueue the queue of post fix fixtures
   * @param op the REAL OP :-)
   * 
   */
  private static void processOperator(Stack<Token> opStack, Queue<Token> postfixQueue, Operator op)
  {
    Token topTok = null;
    if(!opStack.isEmpty())
    {
      topTok = opStack.peek();
    }
    while(!opStack.isEmpty() && !(topTok instanceof LeftParenthesis) && op.getPrecedence() <= ((Operator)topTok).getPrecedence())
    {
      postfixQueue.add(opStack.pop());
      if(!opStack.isEmpty())
      {
        topTok = opStack.peek(); 
      }
    }
    opStack.push(op);
  }
}