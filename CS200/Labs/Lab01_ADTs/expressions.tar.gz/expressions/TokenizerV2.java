/*
 * File: Tokenizer.java
 */

package expressions;

import java.util.*;
import bdkstructures.*;

/**
 * Class that encapsulates methods for extracting tokens from a String
 * that represents an arithmetic expression.
 * 
 * @author <your name here>, based on a template by J. Andrew Holey
 * @version September 25, 2008
 */
public class TokenizerV2 {

 /**
  * Returns a Token based on the supplied token string.
  * 
  * @param tokenStr the string the token is to be based on
  * @return a Token based on the supplied token string
  * @throws IllegalArgumentException if tokenStr doesn't represent a valid token
  */
 public static Token makeToken(String tokenStr) {
  Token result = null;
  char test = tokenStr.charAt(0);
  switch(test) {
    case '+' :
      result = new Plus();
      break;
    case '-' :
      result = new Minus();
      break;
    case '*' :
      result = new Times();
      break;
    case '/' :
      result = new Divide();
      break;
    case '%' :
      result = new Remainder();
      break;
    case '(' :
      result = new LeftParenthesis();
      break;
    case ')' :
      result = new RightParenthesis();
      break;
  }
  if(Character.isDigit(test))
    result = new IntegerLiteral(tokenStr);
  if(result == null)
    throw new IllegalArgumentException("Input needs to be a number or operator");
  return result;
 }
 
 /**
  * Parses the supplied token string and returns a queue of tokens.
  * 
  * @param tokensStr the string the tokens are to be parsed from
  * @return a queue of tokens in the same order they appeared in the original string
  * @throws IllegalArgumentException if tokensStr contains unparseable subsequences
  */
 public static BDKLinkedQueue<Token> parseString(String tokensStr) {
   BDKLinkedQueue<Token> result = new BDKLinkedQueue<Token>();
   String operators = "+-*/%()";
   int i = 0;
   while(i < tokensStr.length()){
     char test = tokensStr.charAt(i);
     if(operators.contains(Character.toString(test)))
     {
       Token operator = makeToken(Character.toString(test));
       result.enqueue(operator);
       i++;
     }
     else if(Character.isDigit(test))
     {
       int j = i+1;
       Token operand = null;
       if(j == tokensStr.length())
         operand = makeToken(tokensStr.substring(i));
       else
       {
         while(Character.isDigit(tokensStr.charAt(j)))
         {
           j++;
         }
         operand = makeToken(tokensStr.substring(i,j));
       }
       result.enqueue(operand);
       i=j;
     }
     else if(Character.isWhitespace(test))
       i++;
     else
       throw new IllegalArgumentException("Not a valid expression");
   }
   return result;
 }
}