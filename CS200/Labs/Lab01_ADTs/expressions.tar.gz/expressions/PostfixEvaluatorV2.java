/**
 * PostfixEvaluator.java
 */

package expressions;
import java.util.*;
import bdkstructures.*;

/**
 * Used to evaluate postfix expressions.
 * 
 * @author Zachary Vetter, Alexis Neas, Trevor Wensman
 * @version 9/26/2017
 */
public class PostfixEvaluatorV2 {

  /**
   * Evaluates an expression in postfix form
   * 
   * pre: the queue cannot be empty
   * 
   * @param postfixQueue the expression
   * 
   * @return the value of the expression
   * @throws IllegalArgumentException if precondition is not met
   * @throws IllegalArgumentException if there is an operator with no operands
   * @throws IllegalArgumentException if there is an operator with only one operand
   * @throws IllegalArgumentException if there are too many operands
   */
  public static int evaluate(BDKLinkedQueue<Token> postfixQueue)
  {
    if(postfixQueue.isEmpty())
      throw new IllegalArgumentException("Empty postfix expression");
    
    BDKLinkedStack<Operand> opStack = new BDKLinkedStack<Operand>();
    while(!postfixQueue.isEmpty())
    {
      Token nextTok = postfixQueue.dequeue();
      if(nextTok instanceof Operand)
        opStack.push((Operand)nextTok);
      else
      {
        if(opStack.isEmpty())
          throw new IllegalArgumentException("Operator with no operands");
        Operand rightOperand = opStack.pop();
        if(opStack.isEmpty())
          throw new IllegalArgumentException("Operator with only one operand");
        Operand leftOperand = opStack.pop();
        Operand answer = ((Operator)nextTok).evaluate(leftOperand, rightOperand);
        opStack.push(answer);
      }
    }
    Operand result = opStack.pop();
    if(!opStack.isEmpty())
      throw new IllegalArgumentException("Too many operands");
    return result.getValue();
  }
}