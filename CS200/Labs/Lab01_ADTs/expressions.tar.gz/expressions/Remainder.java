/**
 * Remainder.java
 */

package expressions;

/**
 * Used for the Remainder operator.
 * 
 * @author Zachary Vetter, Alexis Neas, Trevor Wensman
 * @version 9/20/2017
 */
public class Remainder extends Operator{
  
  /**
   * Taken from the super class.
   * 
   */
  
  public int getPrecedence()
  {
    return 2;
  }
  /**
   * Taken from the super class.
   * 
   */
  public Operand evaluate(Operand operand, Operand operand2)
  {
    return new IntegerLiteral(operand.getValue() % operand2.getValue());
  }
  /**
   * Taken from the interface.
   * 
   */
  public String toString()
  {
    return "%"; 
  }
}