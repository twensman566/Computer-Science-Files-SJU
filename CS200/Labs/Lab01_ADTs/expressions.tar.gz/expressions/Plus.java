/**
 * Plus.java
 */

package expressions;

/**
 * Used for the addition operator.
 * 
 * @author Zachary Vetter, Alexis Neas, Trevor Wensman
 * @version 9/20/2017
 */
public class Plus extends Operator{
  
  /**
   * Taken from the super class.
   * 
   */
  
  public int getPrecedence()
  {
    return 1;
  }
  /**
   * Taken from the super class.
   * 
   */
  public Operand evaluate(Operand operand, Operand operand2)
  {
    return new IntegerLiteral(operand.getValue() + operand2.getValue());
  }
  /**
   * Taken from the interface.
   * 
   */
  public String toString()
  {
    return "+"; 
  }
}