/**
 * RightParenthesis.java
 */

package expressions;

/**
 * Used for right parenthesis in the expression
 * 
 * @author Alexis Neas, Zachary Vetter, Trevor Wensman
 * @version 9/20/2017
 */
public class RightParenthesis implements Token{
  
  /**
   * Taken from the interface.
   */
  public Token.Type getType()
  {
    return Type.RIGHT_PARENTHESIS;
  }
  
  /**
   * Taken from the interface.
   */
  public String toString()
  {
    return ")";
  }
}