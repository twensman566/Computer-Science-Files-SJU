/*
 * File: <FOO>LinkedStack.java
 */
package bdkstructures;

import java.util.*;
import zhstructures.*;

/**
 * Class implementing a ZHStack using an internal
 * one-way linked structure/node.
 * 
 * @author I. Rahal, J. A. Whitford Holey, and Brandan Kalsow, Trevor Wensman
 * @version 9/27/17
 */
public class BDKLinkedQueue<ElementType> implements ZHQueue<ElementType>
{
  
  /**
   * The number of elements in this stack.
   */
  protected int size = 0;
  /**
   * A reference to the front of the queue.
   */
  protected QueueNode front;
  
  /**
   * A reference to the beginning of the queue.
   */
  protected QueueNode rear;
  
  /**
   * Creates a new empty stack.
   */
  public BDKLinkedQueue()
  {
    this.front = new QueueNode();
    this.rear = this.front;
  }
  
  /* (non-Javadoc)
   * @see zhstructures.ZHStack#peek()
   */
  public ElementType peek()
  {
    if(this.isEmpty())
    {
      throw new NoSuchElementException();
    }
    else
    {
    return front.getElement();
    }
  }
  
  /* (non-Javadoc)
   * @see zhstructures.ZHStack#pop()
   */
  public ElementType dequeue()
  {
    if(this.isEmpty())
    {
      throw new NoSuchElementException();
    }
    else
    {
      QueueNode temp = new QueueNode(front.getElement(), null);
      this.front = front.getNext();
      size--;
      return temp.getElement();
    }
  }
  
  /* (non-Javadoc)
   * @see zhstructures.ZHStack#push(java.lang.Object)
   */
  public void enqueue(ElementType element)
  {
    QueueNode temp = new QueueNode();
    size++;
    this.rear.setElement(element);
    this.rear.setNext(temp);
    this.rear = temp;
  }
  
  /* (non-Javadoc)
   * @see zhstructures.ZHCollection#contains(java.lang.Object)
   */
  public boolean contains(ElementType element)
  {
    return this.front.contains(element);
  }
  
  /* (non-Javadoc)
   * @see zhstructures.ZHCollection#isEmpty()
   */
  public boolean isEmpty()
  {
    return this.size==0;
  }
  
  /* (non-Javadoc)
   * @see zhstructures.ZHCollection#size()
   */
  public int size()
  {
    return this.size;
  }
  
  /* (non-Javadoc)
   * @see zhstructures.ZHCollection#iterator()
   */
  public Iterator<ElementType> iterator()
  {
    return this.front.iterator();
  }
  
  /**
   * Class implementing nodes for this stack.
   * 
   * Inherited methods:
   *   boolean contains()
   *   boolean isEmpty()
   *   int size()
   *   Iterator<ElementType> iterator()
   *   ElementType getElement()
   *   void setElement(ElementType element)
   *   QueueNode getNext()
   *   void setNext(QueueNode next)
   */
  protected class QueueNode
    extends ZHOneWayListNode<ElementType, QueueNode>
  {
    
    /**
     * Creates a new empty node.
     */
    protected QueueNode()
    {
      super();
    }
    
    /**
     * Creates a new node with the specified data element and next node.
     * 
     * @param element the data element for the new node
     * @param next the next node for the new node
     */
    protected QueueNode(ElementType element, QueueNode next)
    {
      super(element, next);
    }
  }
}
