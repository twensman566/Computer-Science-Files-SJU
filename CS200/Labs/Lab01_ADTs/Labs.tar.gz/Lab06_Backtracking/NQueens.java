/*
 * File Queens.java
 */

import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Program to find a solution to the 8 queens problem
 * and display the result graphically.
 * 
 * @author Jim Schnepf, modified by J. Andrew Holey
 * @version October, 2012
 */
public class NQueens extends JFrame {
  
  private static final Color QUEENSPOT      = Color.RED;
  private static final Color OPEN           = Color.BLACK;
  
  // delay between redraws of chessboard
  private static int SLEEP_TIME = 1;
  //squares per row or column
  private int BOARD_SIZE = 8;
  
  // used to indicate an empty square
  private static final int EMPTY = 0;
  
  //used to indicate a square containing a queen
  private static int QUEEN = 1;
  
  private int board[][]; // chess board
  private TwoDimGrid GUIBoard;
  
  /**
   * Constructor creates an empty square board
   */
  public NQueens(int size) {
    BOARD_SIZE = size;
    board = new int[BOARD_SIZE][BOARD_SIZE];
    GUIBoard = new TwoDimGrid(BOARD_SIZE, BOARD_SIZE);
    getContentPane().add(GUIBoard, BorderLayout.CENTER);
    pack();
    setVisible(true);
    displayBoard();
  }
  
  /**
   * Clears the board
   * post: Sets all of the squares to EMPTY
   */
  public void clearBoard() {
    for (int i = 0; i < BOARD_SIZE; i++) {
      for (int j = 0; j <  BOARD_SIZE; j++) {
        board[i][j] = EMPTY;
      }
    }
  }
  
  /**
   * Displays the board
   * post: board is displayed using grid
   */
  void displayBoard() {
    
    GUIBoard.recolor(board, QUEENSPOT, OPEN);
    try {
      Thread.sleep(SLEEP_TIME);
    }
    catch(InterruptedException ie) {
      ie.printStackTrace();
      System.exit(1);
    }      
  }
  
  /**
   * Places queens in the colums beginning at the 
   * column specified
   * Precondition: Queens are already placed in all columns preceding currentColumn
   * Post: If a solution is found, each column
   * of the board contains one queen and method returns true;
   * otherwise, returns false (no solution exists for a queen anywhere 
   * in column specified
   */
  public boolean placeQueens(int currentColumn)
  {
    if(currentColumn >= BOARD_SIZE)
      return true;
    
    for(int row = 0; row < BOARD_SIZE; row++)
    {
     if(!isUnderAttack(currentColumn,row))
     {
       setQueen(currentColumn,row);
       if(placeQueens(currentColumn + 1) == true)
       {
         return true;
       }
       else
         removeQueen(currentColumn,row);
     }
     
     
    }
    
    return false;
  }
  
  /**
   * Set a queen on a row indicated by row and column
   * post: Sets the square on the board in a
   * given row and column to QUEEN.
   * 
   */
  private void setQueen(int column, int row) {
    board[column][row] = QUEEN;
    displayBoard();
  }
  
  /** Remove a queen at square indicated by row and column
    *  post: Sets the square on a board in a given row and column 
    * to EMPTY  
    */
  
  private void removeQueen(int column, int row) {
    board[column][row] = EMPTY;
    displayBoard();
  }
  
  /**
   * Determines whether the square on the board at a given 
   * row and column is under attack by any queens in the columns 1 
   * through "column  - 1"
   * @param column the y-coordinate for the square on the board
   * @param row the x-coordinate for the square on the board
   * @return false if placing the queen at square (column, row) is allowed or 
   *         true otherwise
   */
  private boolean isUnderAttack(int column, int row)
  {
    boolean attacked = false;
    
    for (int offset = 0; offset <= column; offset++)
    {
      
      if(row - offset >= 0 && column - offset >= 0)
      {
        if(board[column - offset][row - offset] == QUEEN)
        {
          attacked = true;
          break;
        }
      }
      if(column - offset >= 0)
      {
        if(board[column - offset][row] == QUEEN)
        {
          attacked = true;
          break;
        }
      }
      if(row + offset < BOARD_SIZE && column - offset < BOARD_SIZE)
      {
        if(board[column - offset][row + offset] == QUEEN)
        {
          attacked = true;
          break;
        }
      }
    }
    return attacked;
  }
  
  /**
   * Start the Queens search 
   */
  public static void main(String [] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("Please enter the size of the board");
    int size = scan.nextInt();
    NQueens q = new NQueens(size);
    q.placeQueens(0);
  }
}     




