/*
 * File: Customer.java
 */

import java.util.*;

/** 
 * A class to represent a passenger.
 * 
 * @author Brandan Kalsow & Trevor Wensman
 * @version October 21, 2008
 */

public class Customer {
  
  // Data Fields
  /** The ID number for this passenger. */
  private int customerId;
  
  /** The time needed to process this passenger. */
  private int processingTime;
  
  /** The time this passenger arrives. */
  private int arrivalTime;
  
  /** The maximum time to process a passenger. */
  private static int avgProcessingTime;
  
  /** The sequence number for passengers. */
  private static int idNum = 0;
  
  /**
   * Create a new passenger.
   * 
   * @param arrivalTime the time this passenger arrives
   */
  public Customer(int arrivalTime) {
    this.arrivalTime = arrivalTime;
    processingTime = (int) ((new Random()).nextDouble() * (1.6 * this.avgProcessingTime - 0.4 *  this.avgProcessingTime) + 0.4 * avgProcessingTime);
    customerId = idNum++;
  }
  
  /**
   * Get the arrival time.
   * 
   * @return the arrival time
   */
  public int getArrivalTime() {
    return arrivalTime;
  }
  
  /**
   * Get the processing time.
   * 
   * @return the processing time
   */
  public int getProcessingTime() {
    return processingTime;
  }
  
  /**
   * Get the passenger ID.
   * 
   * @return the passenger ID
   */
  public int getId() {
    return customerId;
  }
  
  /**
   * Set the maximum processing time.
   * 
   * @param maxProcessingTime the new value for the maximum processing time
   */
  public static void setAvgProcessingTime(int avgProcessTime) {
    avgProcessingTime = avgProcessTime;
  }
}
