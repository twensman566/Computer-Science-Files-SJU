/*
 * File BankSim.java
 */

import java.util.*;
import javax.swing.*;

/**
 * Simulate the check-in process of an airline.
 * 
 * @author Koffman & Wolfgang, edited by J. A. Holey & I. M. Rahal
 * @version October 20, 2010
 */
public class BankSim {
  
  // Data Fields
  
  /** Queue of customers. */
  private CustomerQueue CustomersQueue =
    new CustomerQueue("Customer");
  
  /** average time to service a customer. */
  private int avgProcessingTime;
  
  /** Total simulated time. */
  private int totalTime;
  
  /** If set true, print additional output. */      
  private boolean showAll = true;
  
  /** Simulated clock. */
  private int clock = 0;
  
  /** Time that a teller will be done with the current customer.*/
  private int timeDone[];
  
  /**number of tellers currently working at the bank*/
  private int numTellers;
  
  /**array to contain the tellers created*/
  private Teller[] tellers;
  
  private double avgWaitTime;
  
  
  /**
   * Get the data for the simulation.
   */
  private void enterData() {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter totalTime (an integer):" +
                       "The total time to run the simulation");
    totalTime = sc.nextInt();
    System.out.println("Enter avgProcessingTime (an integer): " +
                       "The avererage time to serve a customer");
    avgProcessingTime = sc.nextInt();
    Customer.setAvgProcessingTime(avgProcessingTime);
    
    System.out.println("Enter arrivalRate for customers (a double): " +
                       "The expected number of customer arrivals per unit of time");
    CustomersQueue.setArrivalRate(sc.nextDouble());
    System.out.println("Enter  tellers for bank (in integer): " +
                       "The number of tellers working at the bank");
    numTellers = sc.nextInt();
    tellers = new Teller[numTellers];
    timeDone = new int[numTellers];
    for(int i = 0; i < numTellers; i++)
    {
      tellers[i] = new Teller();
      timeDone[i] = -1;
    }
  }
  
  /**
   * Run the simulation.
   */
  private void runSimulation() {
    for (clock = 0; clock < totalTime; clock++) {
      CustomersQueue.checkNewArrival(clock, showAll);
      for(int i = 0; i < timeDone.length; i++)
      {
      if (clock >= timeDone[i]) { //means that teller is ready to serve (i.e., not busy)
        if(tellers[i].getAvailible()==false)
        {
          tellers[i].toggleAvailible();
        }
        startServe(i);
      }
    }
    }
  }
  
  /**
   * Serve the queues in the simulation.
   */
  private void startServe(int tellerNum) {
      if (!CustomersQueue.isEmpty() && tellers[tellerNum].getAvailible() == true) {
        // Serve the next customer.
        timeDone[tellerNum] = CustomersQueue.update(clock, showAll, tellerNum);
        tellers[tellerNum].toggleAvailible();
        tellers[tellerNum].incrementNumServed();
      }
      else if (showAll) {
        System.out.println("Time is " + clock + ": Teller number " + tellerNum + " is idle");
        tellers[tellerNum].incrementTimeIdle();
      }
    }
  
  /**
   * Show the statistics after the simulation.
   */
  private void showStats() {
    System.out.println("\nThe number of customers served was " +
                       CustomersQueue.getNumServed());
    double averageWaitingTime =
      (double) CustomersQueue.getTotalWait() /
      (double) CustomersQueue.getNumServed();
    System.out.println(" with an average waiting time of " +
                       averageWaitingTime);
    averageWaitingTime =
      (double) CustomersQueue.getTotalWait() /
      (double) CustomersQueue.getNumServed();
    System.out.println("Customers in queue: " +
                       CustomersQueue.size());
    
    for(int i = 0; i < tellers.length; i ++)
    {
      System.out.println("Idle time for teller " + i + " was: " + tellers[i].getTimeIdle()
                           + "\nServed " + tellers[i].getNumServed() + " customers.");
    }
  }
  
  /**
   * Main method for the simulation program.
   * 
   * @param args the command line arguments (not used)
   */
  public static void main(String args[] ){
    BankSim sim = new BankSim();
    sim.enterData();
    sim.runSimulation();
    sim.showStats();
  }
  
}
