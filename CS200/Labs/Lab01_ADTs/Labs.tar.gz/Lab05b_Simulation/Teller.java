  /**
   * class Teller
   * this class represents a teller at a bank
   * @Author: Brandan Kalsow
   * @Version: 9/30/17
   */
  public class Teller
  {
    private boolean availible;
    private int numServed;
    private int timeIdle;
    
    /**Default constructor for the Teller class */
    public Teller()
    {
      this.availible = true;
      this.numServed = 0;
      this.timeIdle = 0;
    }
    
    /**This method sets availible to false if true and vice versa */
    public void toggleAvailible()
    {  
      this.availible = !this.availible;
    }
    
    /**This method returns true if the teller is availible, otherwise false*/
    public boolean getAvailible()
    {
      return this.availible;
    }
    
    /**This method adds 1 to the current number of customers served*/
    public void incrementNumServed()
    {
      numServed++;
    }
    
    /**This method returns the number of customers this teller has served */
    public int getNumServed()
    {
      return this.numServed;
    }
    
    /**This method increases the time idle for this worker*/
    public void incrementTimeIdle()
    {
      timeIdle++;
    }
    
    /**This method returns the time that this teller was idle*/
    public int getTimeIdle()
    {
      return timeIdle;
    }
    
  }
  